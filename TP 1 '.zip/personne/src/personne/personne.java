package personne;

public class personne {

    private String nom;
    private String prenom;
    private int age;
    private String sexe;

    personne() {
        nom = "ben ali";
        prenom = "med";
        age = 30;
        sexe = "masculain";
    }

    personne(String nom, String prenom, int age, String sexe) {
        this.nom = nom;
        this.prenom = prenom;
        this.age = age;
        this.sexe = sexe;
    }

    public String getnom() {
        return nom;
    }

    public String getprenom() {
        return prenom;
    }

    public int getage() {
        return age;
    }

    public String getsexe() {
        return sexe;
    }

    void affiche() {
        System.out.println("nom=" + nom);
        System.out.println("prenom=" + prenom);
        System.out.println("age=" + age);
        System.out.println("sexe=" + sexe);
    }

    boolean samelastname(personne p) {
        if (nom.equals(p.nom)) {
            return true;
        }
        return false;
    }

    
    public  class test {

        public static void main(String[] args) {

            personne p1 = new personne();

            personne p2 = new personne(
                "ben ali", "Ahmed", 25, "masculain"
            );

            p1.affiche();

            System.out.println("----------------");

            p2.affiche();

            System.out.println("----------------");

            if (p1.samelastname(p2))
                System.out.println("Les deux personnes ont le même nom");
            else
                System.out.println("Les deux personnes ont des noms différents");
        }
    }
}